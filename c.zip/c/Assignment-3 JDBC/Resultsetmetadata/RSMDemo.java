import java.io.*;
import java.sql.*;


class RSMDemo
{
	public static void main(String args[])
	{
		Connection con=null;
		ResultSet rs=null;
		ResultSetMetaData rsmd=null;
		Statement stmt=null;
		
		
		try
		{
			Class.forName("org.postgresql.Driver");
			con=DriverManager.getConnection("jdbc:postgresql://localhost/mydb","root","root@123");
			
			stmt=con.createStatement();
			
			rs=stmt.executeQuery("select * from donar");
			
			rsmd=rs.getMetaData();
			int n=rsmd.getColumnCount();
			
			System.out.println("No. of columns:  "+n);
			
			
			for(int i=1;i<=n;i++)
			{
				System.out.println("Column Name:  "+rsmd.getColumnName(i));
				System.out.println("Column Type:  "+rsmd.getColumnTypeName(i));
					
			}
			
			rs.close();
			con.close();
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
	}
}


////sudo -i
//su -l postgres
//createdb mydb
//create role root login superuser password 'root@123';
					