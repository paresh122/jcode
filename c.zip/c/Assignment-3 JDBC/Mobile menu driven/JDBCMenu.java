import java.sql.*;
import java.io.*;
class JDBCMenu
{
  public static void main(String[] args) throws Exception
  {
     
    Statement stmt =  null;
    ResultSet rs = null;
    PreparedStatement ps1 = null, ps2=null;
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    String mname,color,simtype,networktype,batterycapacity,internalstorage,ram,processortype;
    int mno,choice;
    Class.forName("org.postgresql.Driver");
    Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost/tydb","root","root@123");
    stmt = conn.createStatement();
         
    if(conn!=null)
        System.out.println("Connection successful..");
   while(true)
    {
    System.out.println("\n\n1: Insert");
    System.out.println("2: Modify");
    System.out.println("3: Delete ");
    System.out.println("4: Search");
    System.out.println("5: view");
    System.out.println("6: Exit");
    System.out.println("\nEnter your choice : ");
    choice = Integer.parseInt(br.readLine());
    switch(choice)
    {
    
    case 1:
        System.out.println("Enter the model number");
        mno = Integer.parseInt(br.readLine());
        System.out.println(" Enter Model Name:");
        mname = br.readLine();
        System.out.println("Enter Model color:");
        color = br.readLine();
        System.out.println("Enter Simtype:");
        simtype = br.readLine();
        System.out.println("Enter Network type:");
        networktype = br.readLine();
        System.out.println("Enter battery capacity:");
        batterycapacity = br.readLine();
        System.out.println("Enter Internal Storage:");
        internalstorage = br.readLine();
        System.out.println("Enter Ram:");
        ram = br.readLine();
        System.out.println("Enter Processor Type :");
        processortype = br.readLine();
        ps1 = conn.prepareStatement("Insert into mobile values(?,?,?,?,?,?,?,?,?)");
  	    ps1.setInt(1,mno); 
        ps1.setString(2,mname);
        ps1.setString(3,color);
        ps1.setString(4,simtype);
        ps1.setString(5,networktype);
        ps1.setString(6,batterycapacity);
        ps1.setString(7,internalstorage);
        ps1.setString(8,ram);
        ps1.setString(9,processortype);
        ps1.executeUpdate();
        System.out.println("record inserted successfully");
        break; 
        
        
        
    case 2:
        System.out.println("Enter the model number to be modified ");
        mno = Integer.parseInt(br.readLine());
        //System.out.println("Enter new model no: ");
        //mno =Integer.parseInt(br.readLine());
        System.out.println("Enter new model name: ");
        mname = br.readLine();
        System.out.println("Enter new color");
        color = br.readLine();
        System.out.println("Enter new Sim Type:");
        simtype = br.readLine();
        System.out.println("Enter new network Type:");
        networktype = br.readLine();
        System.out.println("Enter  new battery capacity:");
        batterycapacity = br.readLine();
        System.out.println("Enter  new Internal Storage:");
        internalstorage = br.readLine();
        System.out.println("Enter new Ram:");
        ram = br.readLine();
        System.out.println("Enter  new Processor Type :");
        processortype = br.readLine();
                ps2 = conn.prepareStatement("Update mobile set  mname = ?,color = ?,simtype = ?,networktype = ?,batterycapacity = ?,internalstorage = ? , ram = ?, processortype = ? where mno = ?");
             
                ps2.setString(1,mname);
                ps2.setString(2,color);
                ps2.setString(3,simtype);
                ps2.setString(4,networktype);
                ps2.setString(5,batterycapacity);
                ps2.setString(6,internalstorage);
                ps2.setString(7,ram);
                ps2.setString(8,processortype); 
                ps2.setInt(9, mno);
                ps2.executeUpdate();
                System.out.println("record modified successfully");
        break;
        
        
        
    case 3: 
        System.out.println("Enter the model number to be deleted ");
        mno = Integer.parseInt(br.readLine());
        stmt.executeUpdate("Delete from mobile where mno = " + mno);
                System.out.println("record deleted successfully");
        break;
        
        
    case 4:
        System.out.println("Enter the model number to be searched ");
        mno = Integer.parseInt(br.readLine());
        rs = stmt.executeQuery("Select * from mobile where mno = " + mno);
        if(rs.next())
        {
                System.out.print("Model number   = " + rs.getInt(1));
                System.out.println("Model Name   = " + rs.getString(2));
                System.out.println("Model Colour = " + rs.getString(3));
                System.out.println("Sim type     = " + rs.getString(4));
                System.out.println("Network type = " + rs.getString(5));
                System.out.println("Internal storage = " + rs.getString(6));
                System.out.println("Ram              = " + rs.getString(7));
                System.out.println("processor type = " + rs.getString(8));
         }
        
        else
            System.out.println("Model  not found");    
        break;  
        
        
     case 5:
        rs = stmt.executeQuery("Select * from mobile");
        while(rs.next())  
              {
                System.out.print("\n\nModel number   = " + rs.getInt(1));
                System.out.println("\nModel Name   = " + rs.getString(2));
                System.out.println("Model Color = " + rs.getString(3));
                System.out.println("Sim type     = " + rs.getString(4));
                System.out.println("Network type = " + rs.getString(5));
                System.out.println("Battery capacity = " + rs.getString(6));
                System.out.println("Internal storage = " + rs.getString(7));
                System.out.println("Ram              = " + rs.getString(8));
                System.out.println("processor type = " + rs.getString(9));
             }
        break;
        
        default: System.out.println("invalid choice!!! please make valid choice\n\n");
    
    
    
    
     }
   } 
  }
}




//sudo -i
//su -l postgres
//createdb mydb
//create role root login superuser password 'root@123';
//create table mobile(mno int primary key,mname varchar,colour varchar,simtype varchar,networktype varchar,batterycapacity varchar,internalstograge varchar,ram varchar,processortype varchar);
//insert into mobile values(101,'redmi note 8','black','nano','4g','4000mah','32gb','4gb','snapdragon');
//insert into mobile values(102,'iphone13','gold','nano','5g','6000mah','128gb','16gb','A15bionic');

