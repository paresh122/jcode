import java.io.*;
import java.sql.*;


class DBMDemo
{
	public static void main(String args[])
	{
		Connection con=null;
		ResultSet rs=null;
		DatabaseMetaData dbmd=null;
		
		try
		{
			Class.forName("org.postgresql.Driver");
			con=DriverManager.getConnection("jdbc:postgresql://localhost/mydb","root","root@123");
			
			dbmd=con.getMetaData();
			
			System.out.println("Database Product  Name:           "+dbmd.getDatabaseProductName());
			System.out.println("Database version:        "+dbmd.getDatabaseProductVersion());
			System.out.println("Database Driver:         "+dbmd.getDriverName());
			System.out.println("User Name:               "+dbmd.getUserName());
			System.out.println("Database driver version= "+ dbmd.getDriverVersion());
			System.out.println("Database Version =       " + dbmd.getDriverMajorVersion());
			System.out.println("List of tables:-");	
			
			rs=dbmd.getTables(null,null,null,new String[]{"TABLE"});
			
			while(rs.next())
			{
				System.out.println(rs.getString("TABLE_NAME"));
			
			}
			
			con.close();
		
		}

		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
}

//sudo -i
//su -l postgres
//createdb mydb
//create role root login superuser password 'root@123';

