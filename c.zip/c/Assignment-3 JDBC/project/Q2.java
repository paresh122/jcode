import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Connection con =null;
		 PreparedStatement ps =null;
        try
        {
                Class.forName("org.postgresql.Driver");
                con = DriverManager.getConnection("jdbc:postgresql://localhost/mydb","root","root@123");
                System.out.println("Hurry....Got Connected!!!");
                
		 BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		 
		 System.out.print("Enter Project ID:");
		int id=Integer.parseInt(br.readLine());
		
		
		System.out.print("Enter Project Name:");
		String name=br.readLine();
		
		
		System.out.print("Enter Project Description:");
		String desc=br.readLine();
		
		
		System.out.print("Enter Project Status: ");
		String Status=br.readLine();
		 
		 
		ps=con.prepareStatement("insert into project values(?,?,?,?)"); 
		 ps.setInt(1, id);
                 ps.setString(2, name);
                  ps.setString(3,desc);
                   ps.setString(4, Status);
		 
		 int i = ps.executeUpdate();
		 
		 if(i==1)
		 {
		 	System.out.println("Record is inserted Successfully!!!");
		 }
		 else
		 {
		 	System.out.println("Record is not inserted Successfully!!!");
		 }
		 con.close();
		 
		 
		 
                
        }
        catch(Exception e)
        {
        System.out.println("My Problem:" + e);
        }
        System.out.println("Done:)");

        }

	}

////sudo -i
//su -l postgres
//createdb mydb
//create role root login superuser password 'root@123';
// project_id | project_name | project_description | project_status 


