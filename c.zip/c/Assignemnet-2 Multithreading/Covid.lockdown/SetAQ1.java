import java.io.*;
import java.lang.String.*;
class TestPrint extends Thread
{
	String msg="";
	int n;
	TestPrint(String msg, int n)
	{
	  this.msg = msg;
	  this.n = n;
	}
	
	public void run()
	{
	  try{
	    for(int i=1;i<=n;i++)
	    {
	      System.out.println(msg + "" +i + "times");
	    }
	    System.out.println("\n");
	  }
	  catch(Exception e)
	  {
	  
	  }
	  }
	  
}

  public class SetAQ1{
	   		  public static void main(String args[])
	   		  {
	   		     int n = Integer.parseInt(args[0]);
	   		     TestPrint t1 = new TestPrint("COVID",n);
	   		     t1.start();
	   		     
	   		     TestPrint t2 = new TestPrint("LOCKDOWN 2020",n+10);
	   		     t2.start();
	   		     
	   		     TestPrint t3 = new TestPrint("VACCINATED 2021",n+20);
	   		     t3.start();
	   		   
	   		  }
}
