import java.util.Random;

class A extends Thread
{
	public void run()
	{
		Random r = new Random();
		for (int i = 0; i<20; i++)
	        	{
				int randomInteger = r.nextInt(100);
				System.out.println("Random Integer generated : " + randomInteger);
				if((randomInteger%2) == 0) 
				{
					SquareThread sThread = new SquareThread(randomInteger);		

					sThread.start();
				}
				else
			        {
					CubeThread cThread = new CubeThread(randomInteger);
					cThread.start();
				}
				try {
					Thread.sleep(1000);
	      			    }
				catch(InterruptedException e) 
				{
					e.printStackTrace();
				}
			}
	}
}

class SquareThread extends Thread
 {
	int number;

	SquareThread(int randomnumber) 
	{
		number = randomnumber;
	}

	public void run()
	 {
		System.out.println("Square of " + number + " = " + (number * number));
	 }
}

class CubeThread extends Thread 
{
	int number;

	CubeThread(int randomnumber) 
	{
		number = randomnumber;
	}

	public void run()
	 {
		System.out.println("Cube of " + number + " = " + (number * number *number));
	 }
}

public class MultiThreadingTest 
{
	public static void main(String args[])
	 {
		
		A t = new A();
		t.start();
         }
}

