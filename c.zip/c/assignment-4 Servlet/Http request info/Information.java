

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class Information extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
			response.setContentType("text/html");
			
			PrintWriter out= response.getWriter();
			out.println("<br> Request methood     "+request.getMethod());
			out.println("<br> Request url     "+request.getRequestURI());
			out.println("<br> protocol     "+request.getProtocol());
			out.println("<br> Remote address     "+request.getRemoteAddr());
			out.println("<br> server name     "+request.getServerName());
			out.println("<br> Port number     "+request.getServerPort());
			
			ServletContext c = this.getServletContext();
			
			out.println("<br> server software :    "+c.getServerInfo());
			
			
			
			
			
			
			
		
	}

}
