//Click on the file –New- Dynamic Web project-Project Name-Click on the next-next-Click on the Checkbok Generate Web.xml deployment descriptor-finish.
//Right click on WebContent –new-HTML file-index.html


//Right click on src folder- New- Servlet-Class name-Servlet1-Next-Next-Finish
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
public class Servlet1 extends HttpServlet 
{  
    Connection con;
    public void init()
    {
       try
       {
            Class.forName("jdbc.postgresql.Driver");
			con=DriverManager.getConnection("jdbc:postgres:java","admin","123456");
       }
       catch(Exception ce)
       {   
           System.out.println("Error"+ce.getMessage());
       }
 
    }
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException 
    {
        resp.setContentType("text/html");
        PrintWriter pw=resp.getWriter();        
        try
        {
            int id =Integer.parseInt(req.getParameter("id"));           
            String qry="Select * from customer where id="+id;           
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(qry);            
            while(rs.next())
            {
                pw.print("<table border=1>");
                pw.print("<tr>");
                pw.print("<td>" + rs.getInt(1) + "</td>");
                pw.print("<td>" + rs.getString(2) + "</td>");
                pw.print("<td>" + rs.getString(3) + "</td>");
                pw.print("</tr>");
                pw.print("</table>");
            }
        }
        catch(Exception se){}
        pw.close();
    }
}


//Create table customer and insert the values for customer id , customer name and customer address
//Copy the jar files –web Content- Web INF-right click on lib- paste
//Right Click on jar file-Buildpath-add to Build Path
//Right click on index.html file – run as Tomcat Server.
