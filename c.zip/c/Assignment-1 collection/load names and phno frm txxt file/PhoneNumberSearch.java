import java.io.*;
import java.util.*;

public class PhoneNumberSearch
{
	public static void main(String args[])throws IOException
	{
		Hashtable<String,String> ht=new Hashtable<String,String> ();
		FileReader fr = new FileReader("phone.txt");
		BufferedReader br = new BufferedReader(fr);
		
		while(true)
		{
			String line=br.readLine();
			
			if(line==null)
				break;
			String tok[]=line.split("\t");
			ht.put(tok[1],tok[0]);
		}
		
		System.out.println("loaded hashtable:  "+ht);
		
		BufferedReader br2 = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the phone number"  );
		String phno = br2.readLine();
		String name = ht.get(phno);
		
		if(name==null)
		
			System.out.println("no such phone number found");
		else
			System.out.println("found name:  "+name);
				
			
		
	}
	
	
}

