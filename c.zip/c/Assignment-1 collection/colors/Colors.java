import java.io.*;
import java.util.*;

public class Colors
{
	public static void main(String args[])throws Exception
	{
		TreeSet ts = new TreeSet();
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		//System.out.println("enter the colors name:  ");
		//String s  =br.readLine();
		
		for( int i=0;i<3;i++)
		{
			System.out.println("enter the color name:  ");
			String s  =br.readLine();
		   	ts.add(s);
		}
		
	
		System.out.println("colors name:  "+ts);
	}
}
