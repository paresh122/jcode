import java.util.*;
import java.io.*;

public class Friends
{
	public static void main(String [] args) throws Exception
	{
	
		LinkedList li = new LinkedList();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("how many friends: ");
		int n=Integer.parseInt(br.readLine());
		//int n=Integer.parseInt(br.readLine());
		
		System.out.println("enter the friends name");
		
		int i;
		for(i=0;i<n;i++)
		{
			li.add(br.readLine());
		}	
	
		System.out.println("Names in link list are: "+li);
	}
	

}
