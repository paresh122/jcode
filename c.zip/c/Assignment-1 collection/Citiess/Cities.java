import java.util.*;
import java.io.*;

public class Cities
{
	public static void main(String [] args) throws Exception
	{
	
		BufferedReader br = new BufferedReader( new InputStreamReader(System.in));
		ArrayList al = new ArrayList();
		
		System.out.println("How many cities?: ");
		
		int n=Integer.parseInt(br.readLine());
		System.out.println("enter the cities name: ");
		for( int i=0;i<n;i++)
		{
		
			al.add(br.readLine());
		}
		
		System.out.println("Cities in arraylist are:" +al);
		al.removeAll(al);
		System.out.println("removed cities in arraylist:  "+al);	
	
	}



}



