import java.io.*;
import java.util.*;

public class Hashmapsort
{	public static void main(String[] args) throws Exception
	{
	HashMap <String,Integer> hm = new HashMap<String,Integer>();
	
	hm.put("ABC",123);
	hm.put("UVQ",236);
	hm.put("XYZ",785);
	hm.put("PQR",035);
	System.out.println("orignal data before sorting:    "+hm);
	TreeMap<String,Integer> tm = new TreeMap<String,Integer>();
	tm.putAll(hm);
	
	System.out.println("Ascending sorted map:   "+tm);
	System.out.println("descending sorted map:   "+tm.descendingMap());
	
}	}
