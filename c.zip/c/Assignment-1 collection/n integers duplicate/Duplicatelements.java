import java.io.*;
import java.util.*;

public class Duplicatelements

{
	public static void main(String args[]) throws Exception
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		TreeSet<Integer> ts =new TreeSet<Integer>();

		System.out.println("how many numbers: ");
		int n = Integer.parseInt(br.readLine());

		for(int i=0;i<n;)
		{	
			System.out.println("enter the  numbers: ");
			
			int num=Integer.parseInt(br.readLine());
			

			boolean status=ts.add(num);

			if(status==true)
			{
				i++;
			}

			else
			{
				System.out.println("number is alredy present");
			}


		}

		System.out.println("sorted  numbers are: " +ts);
	}
}
