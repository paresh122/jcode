import java.io.*;
import java.util.*;

public class PhoneNumbers
{
	
	public static void main(String[] args)throws Exception
	{
		Hashtable<String,Integer>  ht =new Hashtable<String,Integer>();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int i;
		for(i=0; i<3; i++)
		{
			
			System.out.println("Enter the name: ");
			String name= br.readLine();
			System.out.println("ENter the number: ");
			int n= Integer.parseInt(br.readLine());
			ht.put(name,n);
			
			
		}
		System.out.println("list is:  "+ht);
	}
	
	

}
